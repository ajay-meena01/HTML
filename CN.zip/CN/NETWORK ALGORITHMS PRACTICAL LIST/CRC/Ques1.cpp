#include<iostream>
using namespace std;
class CRC{
    public:
    string message, key;
    CRC(string message, string key){
        this->message=message;
        this->key= key;
    }
    string XOR(string a, string b){
        string result="";
        for(int i=1; i<b.length(); i++){
            if(a[i]==b[i]){
                result+='0';
            }
            else{
                result+='1';
            }
        }
        return result;
    }
    string Ans(string divident, string divisor){
        int pick= divisor.length();
        int n= divident.length();
        string temp = divident.substr(0,pick);
        while(pick<n){
            if(temp[0]=='1'){
                temp= XOR(divisor, temp) + divident[pick];
            }
            else{
                temp= XOR(string(pick,'0'),temp) + divident[pick];
            }
            pick++;
        }
        if(temp[0]=='1'){
            temp= XOR(divisor, temp);
        }
        else{
            temp= XOR(string(pick,'0'),temp);
        }
        return temp;
    }
    void Data(){
        string apand_message = (message + string(key.length()-1,'0'));
        string remainder = Ans(apand_message, key);
        string EnCoded = message+remainder;

        cout<<"Remainder: "<<remainder<<endl;
        cout<<"EnCoded message= message + remainder = ";
        cout<<message<<" + "<<remainder<<" = "<<EnCoded<<endl;
        message = message + remainder;
    }
    void decoded_Data(){
        string remainder = Ans(message,key);
        if(remainder !=string(key.length()-1,'0'))
        cout<<"Data is correct.";
        else
        cout<<"Data is corrupted means data incorrect.";
    }
};
int main(){
    string message, key;
    // message ="10011101";
    // key ="1001";  //then Remainder="100"
    cout<<"Enter a message in form of Binary Bits: ";
    cin>>message;
    cout<<"Enter a key in form of Binary Bits: ";
    cin>>key;
    CRC a(message, key);
    a.Data();
    a.decoded_Data();
    return 0;
}