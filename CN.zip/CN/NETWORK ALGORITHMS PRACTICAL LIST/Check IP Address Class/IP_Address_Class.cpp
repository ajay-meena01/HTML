#include <iostream>
#include <string>
#include <vector>

using namespace std;

string checkIPClass(const string& ipAddress) {
    vector<int> octets;
    string octet = "";
    
    // Extract octets from the IP address
    for (char c : ipAddress) {
        if (c == '.') {
            octets.push_back(stoi(octet));
            octet = "";
        } else {
            octet += c;
        }
    }
    octets.push_back(stoi(octet)); // Add the last octet
    
    // Check if the IP address has 4 octets
    if (octets.size() != 4) {
        return "Invalid IP address";
    }
    
    // Check the class of the IP address based on the first octet
    int firstOctet = octets[0];
    if (firstOctet >= 1 && firstOctet <= 126) {
        return "Class A";
    } else if (firstOctet >= 128 && firstOctet <= 191) {
        return "Class B";
    } else if (firstOctet >= 192 && firstOctet <= 223) {
        return "Class C";
    } else if (firstOctet >= 224 && firstOctet <= 239) {
        return "Class D (Multicast)";
    } else if (firstOctet >= 240 && firstOctet <= 255) {
        return "Class E (Reserved)";
    } else {
        return "Invalid IP address";
    }
}

int main() {
    string ipAddress;
    cout<<"Enter the IP Address: ";
    cin>>ipAddress;
    cout << "IP Address: " << ipAddress << endl;
    cout << "Class: " << checkIPClass(ipAddress) << endl;
    return 0;
}
